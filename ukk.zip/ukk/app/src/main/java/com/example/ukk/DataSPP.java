package com.example.ukk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DataSPP extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_s_p_p);
    }
}
